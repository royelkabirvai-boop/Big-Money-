const startMoneyInput = document.getElementById('startMoney');
const updateMoneyBtn = document.getElementById('updateMoney');
const investmentsList = document.getElementById('investmentsList');
const addInvestmentBtn = document.getElementById('addInvestment');

const newName = document.getElementById('newName');
const newMin = document.getElementById('newMin');
const newMax = document.getElementById('newMax');
const newColor = document.getElementById('newColor');

updateMoneyBtn.addEventListener('click', () => {
    totalMoney = parseInt(startMoneyInput.value);
    alert(`Start money updated to $${totalMoney}`);
});

function renderInvestments() {
    investmentsList.innerHTML = '';
    investments.forEach((inv, i) => {
        const div = document.createElement('div');
        div.innerHTML = `${inv.name} | Min: ${inv.min} | Max: ${inv.max} | Color: <span style="background:${inv.color}; padding:5px 10px;">&nbsp;</span> <button onclick="removeInvestment(${i})">Remove</button>`;
        investmentsList.appendChild(div);
    });
}

addInvestmentBtn.addEventListener('click', () => {
    investments.push({
        name: newName.value,
        min: parseInt(newMin.value),
        max: parseInt(newMax.value),
        color: newColor.value
    });
    newName.value = '';
    newMin.value = '';
    newMax.value = '';
    renderInvestments();
    alert('Investment added!');
});

function removeInvestment(index){
    investments.splice(index,1);
    renderInvestments();
}

renderInvestments();
let investments = [
    {name: "Red", min: 5, max: 10, color: "red"},
    {name: "Green", min: 1, max: 20, color: "green"},
    {name: "Blue", min: -10, max: 15, color: "blue"}
];

let totalMoney = 100;
const totalMoneyElem = document.getElementById('totalMoney');
const investmentButtons = document.getElementById('investmentButtons');

function renderButtons() {
    investmentButtons.innerHTML = '';
    investments.forEach((inv) => {
        const btn = document.createElement('button');
        btn.innerText = inv.name;
        btn.style.backgroundColor = inv.color;
        btn.className = 'trade-btn';
        btn.addEventListener('click', () => {
            const profit = Math.floor(Math.random() * (inv.max - inv.min + 1)) + inv.min;
            totalMoney += profit;
            if (totalMoney < 0) totalMoney = 0;
            totalMoneyElem.innerText = totalMoney;
            alert(`You invested in ${inv.name} and ${profit >=0 ? 'earned' : 'lost'} $${Math.abs(profit)}!`);
        });
        investmentButtons.appendChild(btn);
    });
}

renderButtons();